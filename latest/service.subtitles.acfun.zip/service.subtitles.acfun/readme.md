# Acfun 弹幕插件 for kodi 0.1.1
## 简介
- 获取并挂载acfun任意视频和番剧的弹幕，支持配合acfun插件显示弹幕，也可以用于本地nas上的番剧或者bangumi插件显示弹幕
## 主要功能
> - [x] 搜索视频/番剧弹幕  
> - [x] 自动转换acfun json -> bilibili xml -> ass弹幕
## 更新历史
> -[v0.1.1]----------------------  
 > 修复 - 过长搜索关键词导致搜索失败  
## 使用到的开源项目
- https://github.com/taxigps/xbmc-addons-chinese
- https://github.com/m13253/danmaku2ass
- https://github.com/shaolin-kongfu/danmu
